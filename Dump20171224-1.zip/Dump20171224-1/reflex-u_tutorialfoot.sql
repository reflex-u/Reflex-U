-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: reflex-u
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tutorialfoot`
--

DROP TABLE IF EXISTS `tutorialfoot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tutorialfoot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `steps` varchar(1000) NOT NULL,
  `video` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tutorialfoot`
--

LOCK TABLES `tutorialfoot` WRITE;
/*!40000 ALTER TABLE `tutorialfoot` DISABLE KEYS */;
INSERT INTO `tutorialfoot` VALUES (1,'Anxiety','According to traditional Chinese medical theory, emotional stress and anxiety particularly involves the kidneys, heart, liver and spleen. Massaging these points on your feet is therefore recommended. ','1. Sit on a firm but comfortable chair, or on the edge of your bed.<br>2. Lift one foot and rest it on the knee of the other leg so that you can see the bottom of your foot.<br> 3. If you divide the length of your sole, between the base of your toes and your heel, into thirds,  the point is found at the junction of the first and middle thirds. <br>4. Use the tip of your thumb to press the point deeply for 1-2 minutes. If your thumb gets sore,  rest it for a moment then continue. <br>5. Press hard enough to cause a comfortable pain. <br>6. Repeat on the other foot, using the other thumb.<br>','https://www.youtube.com/embed/8xfuD6z7xos'),(2,'BackPain','You can treat lower back pain by applying pressure to the reflexes on the soles of your feet, the entire area around your heel and around your ankle, as well as the inner edge of each foot. You can treat upper back pain by applying reflexology to the reflex points for your shoulders and upper back,  which are represented on the soles and tops of your feet just beneath the base of your toes.','The spine reflex points follow the line of the inside edge of your foot.<br> 1. Support your right foot with your left hand.<br> 2. Use your right thumb to work all of the spine reflexes that are located along the inside edge of your foot. (from the tip of your big toe all the way to your ankle.)<br>3. Starting at your toe, press your thumb firmly into the skin and move slowly along the whole length of your foot.<br>4. Repeat on the other foot.<br>','https://www.youtube.com/embed/D4tLb2i0wEY'),(3,'BeforeSleep','A simple reflexology routine that works on just the feet can help you to drift off to sleep naturally.  There are nearly 15,000 nerves in your feet alone, one of many reasons that foot reflexology is so calming,  soothing and effective.','1. Relax the feet, one at a time.<br> 2. With simple relaxation techniques: pressing and squeezing, lightly slapping or gently kneading. <br> 3. Finish by pressing and holding your thumb on the solar plexus point of each foot for 5-10 seconds each.<br> 4. On the bottom of each foot, \"walk\" your thumb up from the base of the heel to each toe. <br> 5. Press these reflex points with the outer edge of your thumb or tip of your forefinger. <br> 6. End with \"breeze strokes\" - lightly running your fingertips down the tops, bottoms and sides of each foot. <br>','https://www.youtube.com/embed/v40PWlIg7BI'),(4,'Constipation','Reflexology for Constipation relief tips can real life savers, sometimes constipation is unexpected and can be extremely painful if not very uncomfortable at the least. The following techniques are for mild and unexpected constipation.','1. Use the Thumb Walking technique.<br>2. Thumb walk criss-crossed one way and then the other way across the whole small intestine area.<br> 3. Thumb walk the large intestine area .<br>4. Begin with right foot, thumb walk vertically up to the point where the large intestine bends ninety degrees.<br> 5. Thumb walk across the foot horizontally following the large intestine all the way to the middle of the right foot.<br>6. Repeat step 3 to 5 for 1-2 minutes. <br>  7. Thumb walk large intestine area on left foot, walk horizontally across large intestine area. <br>8. At edge of foot thumb walk vertically downwards then back across. <br> 9. Repeat step 7 and 8 for 1-2 minutes. <br> 10. Continue on the left foot.<br>','https://www.youtube.com/embed/G6xl4X6lfxs'),(5,'Headache','The area of the head is represented on the foot by the big toe; the other toes also represent the head and the sinuses and teeth as well. ','Headache at the Temples<br>The point on your foot that represents the temple area is located just inside the big toe. Simply applying pressure and releasing several times can ease the pain of a temple-centered headache. The left foot is used for the left side of the head, right foot for the right side.<br><br>Sinus Headaches<br>The second joint down on each toe, front and back, represents your face and sinuses. To help relieve a sinus headache, firmly massage this small area of the foot to ease pressure. A squeeze and release technique is generally used. For this type of headache, it is best to work both feet. <br><br>Headaches in the Center, Front or Back of the Head<br>The outside base of each big toe is associated with the brain, while the top of each toe, front and back, is the point of contact for a generalized headache.  For the brain area, rubbing the area firmly is suggested.  The head area is manipulated by pinching each of the toes on both feet.','https://www.youtube.com/embed/k4Ro6vOke8E'),(6,'MenstrualCramp','Reflexology treatment for Pre-Menstrual Syndrome (PMS) must include this point. It is located in the arch of the inside of the foot, a thumb width from the ball of the foot.  Stimulation of this point by pressing it with the fingers helps in relieving abdominal cramps.','1. Located four finger widths above your inner ankle bone, just behind the shinbone, it helps relax the cervix, according to Chinese medicine. (If you feel pain when you press down, you\'re on the wrong spot.)<br> 2. Take your thumb and press on the point for six seconds, then release it for two seconds.Keep this up for five minutes.<br>3. Switch to the other leg and repeat.<br>','https://www.youtube.com/embed/xvxBwqhwXzY');
/*!40000 ALTER TABLE `tutorialfoot` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-24 21:07:54
